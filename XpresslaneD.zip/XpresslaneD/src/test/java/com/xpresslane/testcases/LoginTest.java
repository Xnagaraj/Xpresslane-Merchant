package com.xpresslane.testcases;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.xpresslane.base.TestBase;
import com.xpresslane.utilities.MyScreenRecorder;

public class LoginTest extends TestBase {
	@Test(priority = 2)
	public void loginasmerchant() throws Exception
	{
		MyScreenRecorder.startRecording("loginasmerchant");
		
		type("meremail_XPATH", "altprice@xpresslane.in");
		type("merpassword_XPATH", "madhu@1234");
		click("loginbutton_XPATH");
		
		Assert.assertTrue(isElementPresent(By.xpath(OR.getProperty("prepaidDiscounts_XPATH"))), "Login not successful");

		MyScreenRecorder.stopRecording();
		// Assert.fail("fail");
	}

	@Test(priority = 0)
	public void forgotpassword() throws Exception
	{
		MyScreenRecorder.startRecording("forgotpassword");
		
		click("forgotpasswordlink_XPATH");
		clear("emailtextbox_XPATH");
		
		type("emailtextbox_XPATH", "altprice");
		click("submitbutton_XPATH");

		Thread.sleep(2000);
		verifyEquals("Please provide a valid email", "*Please provide a valid email");
		
		MyScreenRecorder.stopRecording();
		//Assert.fail("Fail");
	}

	@Test(priority = 1)
	public void forgotpassword1() throws Exception
	{
		MyScreenRecorder.startRecording("forgotpassword1");
		
		clear("emailtextbox_XPATH");
		
		type("emailtextbox_XPATH", "altprice@gmail.com");
		click("submitbutton_XPATH");
		Thread.sleep(2000);
		
		verifyEquals("abc", "* Could not find any User : record not found");
		click("cancelbutton_XPATH");
		
	    MyScreenRecorder.stopRecording();
	}

}
